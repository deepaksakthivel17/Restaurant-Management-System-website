from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
from pathlib import Path

app = Flask(__name__)
CORS(app)

DB_PATH = Path(__file__).with_name("servesmart.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with get_db() as db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS foods (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                price REAL NOT NULL CHECK(price > 0),
                category TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS restaurant_tables (
                number INTEGER PRIMARY KEY,
                booked INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer TEXT NOT NULL,
                food_id INTEGER NOT NULL,
                food_name TEXT NOT NULL,
                quantity INTEGER NOT NULL CHECK(quantity > 0),
                unit_price REAL NOT NULL,
                total REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'Pending'
                    CHECK(status IN ('Pending', 'Preparing', 'Served', 'Paid')),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(food_id) REFERENCES foods(id)
            );
        """)

        food_count = db.execute("SELECT COUNT(*) FROM foods").fetchone()[0]
        if food_count == 0:
            db.executemany(
                "INSERT INTO foods (name, price, category) VALUES (?, ?, ?)",
                [
                    ("Chicken Biryani", 180, "Lunch"),
                    ("Veg Fried Rice", 120, "Lunch"),
                    ("Masala Dosa", 60, "Breakfast"),
                    ("Fresh Juice", 50, "Drinks"),
                ],
            )

        table_count = db.execute(
            "SELECT COUNT(*) FROM restaurant_tables"
        ).fetchone()[0]
        if table_count == 0:
            db.executemany(
                "INSERT INTO restaurant_tables (number, booked) VALUES (?, 0)",
                [(number,) for number in range(1, 11)],
            )


def error(message, status=400):
    return jsonify({"error": message}), status


@app.get("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "message": "ServeSmart Python backend is running"
    })


# FOOD MENU
@app.get("/api/foods")
def get_foods():
    with get_db() as db:
        rows = db.execute("SELECT * FROM foods ORDER BY id DESC").fetchall()
    return jsonify([dict(row) for row in rows])


@app.post("/api/foods")
def add_food():
    data = request.get_json(silent=True) or {}
    name = data.get("name")
    category = data.get("category")
    price = data.get("price")

    if not isinstance(name, str) or not name.strip():
        return error("Food name is required.")
    if not isinstance(category, str) or not category.strip():
        return error("Food category is required.")
    try:
        price = float(price)
    except (TypeError, ValueError):
        return error("Price must be a valid number.")
    if price <= 0:
        return error("Price must be greater than zero.")

    with get_db() as db:
        cursor = db.execute(
            "INSERT INTO foods (name, price, category) VALUES (?, ?, ?)",
            (name.strip(), price, category.strip()),
        )
        row = db.execute(
            "SELECT * FROM foods WHERE id = ?", (cursor.lastrowid,)
        ).fetchone()
    return jsonify(dict(row)), 201


@app.delete("/api/foods/<int:food_id>")
def delete_food(food_id):
    with get_db() as db:
        linked = db.execute(
            "SELECT COUNT(*) FROM orders WHERE food_id = ? AND status != 'Paid'",
            (food_id,),
        ).fetchone()[0]
        if linked:
            return error("Food is linked to an unpaid order.", 409)

        cursor = db.execute("DELETE FROM foods WHERE id = ?", (food_id,))
        if cursor.rowcount == 0:
            return error("Food item not found.", 404)
    return jsonify({"message": "Food item deleted."})


# CUSTOMER ORDERS
@app.get("/api/orders")
def get_orders():
    with get_db() as db:
        rows = db.execute("SELECT * FROM orders ORDER BY id DESC").fetchall()
    return jsonify([dict(row) for row in rows])


@app.post("/api/orders")
def add_order():
    data = request.get_json(silent=True) or {}
    customer = data.get("customer")
    food_id = data.get("foodId")
    quantity = data.get("quantity")

    if not isinstance(customer, str) or not customer.strip():
        return error("Customer name is required.")

    try:
        food_id = int(food_id)
        quantity = int(quantity)
    except (TypeError, ValueError):
        return error("Food ID and quantity must be whole numbers.")

    if quantity < 1:
        return error("Quantity must be at least 1.")

    with get_db() as db:
        food = db.execute(
            "SELECT * FROM foods WHERE id = ?", (food_id,)
        ).fetchone()
        if food is None:
            return error("Food item not found.", 404)

        total = round(food["price"] * quantity, 2)
        cursor = db.execute(
            """
            INSERT INTO orders
            (customer, food_id, food_name, quantity, unit_price, total)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                customer.strip(),
                food["id"],
                food["name"],
                quantity,
                food["price"],
                total,
            ),
        )
        row = db.execute(
            "SELECT * FROM orders WHERE id = ?", (cursor.lastrowid,)
        ).fetchone()

    return jsonify(dict(row)), 201


@app.patch("/api/orders/<int:order_id>/status")
def update_order_status(order_id):
    data = request.get_json(silent=True) or {}
    new_status = data.get("status")
    allowed_transitions = {
        "Pending": ["Preparing"],
        "Preparing": ["Served"],
        "Served": ["Paid"],
    }

    with get_db() as db:
        order = db.execute(
            "SELECT * FROM orders WHERE id = ?", (order_id,)
        ).fetchone()

        if order is None:
            return error("Order not found.", 404)
        if new_status not in allowed_transitions.get(order["status"], []):
            return error(
                f"Cannot change order status from {order['status']} to {new_status}.",
                409,
            )

        db.execute(
            "UPDATE orders SET status = ? WHERE id = ?",
            (new_status, order_id),
        )
        updated = db.execute(
            "SELECT * FROM orders WHERE id = ?", (order_id,)
        ).fetchone()

    return jsonify(dict(updated))


# RESTAURANT TABLES
@app.get("/api/tables")
def get_tables():
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM restaurant_tables ORDER BY number"
        ).fetchall()

    return jsonify([
        {"number": row["number"], "booked": bool(row["booked"])}
        for row in rows
    ])


@app.patch("/api/tables/<int:table_number>")
def update_table(table_number):
    data = request.get_json(silent=True) or {}
    booked = data.get("booked")

    if not isinstance(booked, bool):
        return error("The booked field must be true or false.")

    with get_db() as db:
        cursor = db.execute(
            "UPDATE restaurant_tables SET booked = ? WHERE number = ?",
            (1 if booked else 0, table_number),
        )
        if cursor.rowcount == 0:
            return error("Table not found.", 404)

        row = db.execute(
            "SELECT * FROM restaurant_tables WHERE number = ?",
            (table_number,),
        ).fetchone()

    return jsonify({"number": row["number"], "booked": bool(row["booked"])})


# BILLING / DASHBOARD REPORTS
@app.get("/api/reports")
def get_reports():
    with get_db() as db:
        totals = db.execute("""
            SELECT
                COUNT(*) AS totalOrders,
                COALESCE(SUM(
                    CASE WHEN status = 'Paid' THEN total ELSE 0 END
                ), 0) AS paidRevenue,
                COALESCE(SUM(
                    CASE WHEN status != 'Paid' THEN 1 ELSE 0 END
                ), 0) AS unpaidOrders
            FROM orders
        """).fetchone()

        available_tables = db.execute(
            "SELECT COUNT(*) FROM restaurant_tables WHERE booked = 0"
        ).fetchone()[0]
        menu_items = db.execute(
            "SELECT COUNT(*) FROM foods"
        ).fetchone()[0]

    result = dict(totals)
    result["availableTables"] = available_tables
    result["menuItems"] = menu_items
    return jsonify(result)


@app.errorhandler(404)
def not_found(_):
    return jsonify({"error": "Route not found."}), 404


if __name__ == "__main__":
    init_db()
    print("ServeSmart Python backend: http://127.0.0.1:5000")
    print("Health check: http://127.0.0.1:5000/api/health")
    app.run(host="127.0.0.1", port=5000, debug=True)
