const express = require("express");
const cors = require("cors");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// SQLite database file is created automatically in this folder.
const db = new Database(path.join(__dirname, "servesmart.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// Create database tables.
db.exec(`
  CREATE TABLE IF NOT EXISTS foods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL NOT NULL CHECK(price > 0),
    category TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS restaurant_tables (
    number INTEGER PRIMARY KEY,
    booked INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer TEXT NOT NULL,
    food_id INTEGER NOT NULL,
    food_name TEXT NOT NULL,
    quantity INTEGER NOT NULL CHECK(quantity > 0),
    unit_price REAL NOT NULL,
    total REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending'
      CHECK(status IN ('Pending','Preparing','Served','Paid')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(food_id) REFERENCES foods(id)
  );
`);

// Add sample menu items and ten tables only when database is empty.
const foodCount = db.prepare("SELECT COUNT(*) AS count FROM foods").get().count;
if (foodCount === 0) {
  const insertFood = db.prepare(
    "INSERT INTO foods (name, price, category) VALUES (?, ?, ?)"
  );
  const seedFoods = db.transaction(() => {
    insertFood.run("Chicken Biryani", 180, "Lunch");
    insertFood.run("Veg Fried Rice", 120, "Lunch");
    insertFood.run("Masala Dosa", 60, "Breakfast");
    insertFood.run("Fresh Juice", 50, "Drinks");
  });
  seedFoods();
}

const tableCount = db.prepare(
  "SELECT COUNT(*) AS count FROM restaurant_tables"
).get().count;
if (tableCount === 0) {
  const insertTable = db.prepare(
    "INSERT INTO restaurant_tables (number, booked) VALUES (?, 0)"
  );
  const seedTables = db.transaction(() => {
    for (let n = 1; n <= 10; n++) insertTable.run(n);
  });
  seedTables();
}

function sendError(res, status, message) {
  return res.status(status).json({ error: message });
}

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "ServeSmart backend is running" });
});

// FOOD MENU
app.get("/api/foods", (req, res) => {
  const foods = db.prepare("SELECT * FROM foods ORDER BY id DESC").all();
  res.json(foods);
});

app.post("/api/foods", (req, res) => {
  const { name, price, category } = req.body;
  if (typeof name !== "string" || !name.trim()) {
    return sendError(res, 400, "Food name is required.");
  }
  if (!Number.isFinite(Number(price)) || Number(price) <= 0) {
    return sendError(res, 400, "Price must be greater than zero.");
  }
  if (typeof category !== "string" || !category.trim()) {
    return sendError(res, 400, "Category is required.");
  }

  const result = db.prepare(
    "INSERT INTO foods (name, price, category) VALUES (?, ?, ?)"
  ).run(name.trim(), Number(price), category.trim());

  const food = db.prepare("SELECT * FROM foods WHERE id = ?").get(result.lastInsertRowid);
  res.status(201).json(food);
});

app.delete("/api/foods/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return sendError(res, 400, "Invalid food ID.");

  const linked = db.prepare(
    "SELECT COUNT(*) AS count FROM orders WHERE food_id = ? AND status != 'Paid'"
  ).get(id).count;
  if (linked > 0) {
    return sendError(res, 409, "Food is linked to an unpaid order.");
  }

  const result = db.prepare("DELETE FROM foods WHERE id = ?").run(id);
  if (!result.changes) return sendError(res, 404, "Food item not found.");
  res.json({ message: "Food item deleted." });
});

// ORDERS
app.get("/api/orders", (req, res) => {
  const orders = db.prepare("SELECT * FROM orders ORDER BY id DESC").all();
  res.json(orders);
});

app.post("/api/orders", (req, res) => {
  const { customer, foodId, quantity } = req.body;
  const qty = Number(quantity);
  const id = Number(foodId);

  if (typeof customer !== "string" || !customer.trim()) {
    return sendError(res, 400, "Customer name is required.");
  }
  if (!Number.isInteger(qty) || qty < 1) {
    return sendError(res, 400, "Quantity must be a positive whole number.");
  }

  const food = db.prepare("SELECT * FROM foods WHERE id = ?").get(id);
  if (!food) return sendError(res, 404, "Food item not found.");

  const total = Number((food.price * qty).toFixed(2));
  const result = db.prepare(`
    INSERT INTO orders
      (customer, food_id, food_name, quantity, unit_price, total)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(customer.trim(), food.id, food.name, qty, food.price, total);

  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(result.lastInsertRowid);
  res.status(201).json(order);
});

app.patch("/api/orders/:id/status", (req, res) => {
  const id = Number(req.params.id);
  const { status } = req.body;
  const allowed = ["Pending", "Preparing", "Served", "Paid"];

  if (!Number.isInteger(id)) return sendError(res, 400, "Invalid order ID.");
  if (!allowed.includes(status)) return sendError(res, 400, "Invalid order status.");

  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(id);
  if (!order) return sendError(res, 404, "Order not found.");
  if (order.status === "Paid") return sendError(res, 409, "Paid orders cannot be changed.");

  const validNext = {
    Pending: ["Preparing"],
    Preparing: ["Served"],
    Served: ["Paid"]
  };
  if (!validNext[order.status].includes(status)) {
    return sendError(res, 409, `Cannot change ${order.status} to ${status}.`);
  }

  db.prepare("UPDATE orders SET status = ? WHERE id = ?").run(status, id);
  res.json(db.prepare("SELECT * FROM orders WHERE id = ?").get(id));
});

// TABLES
app.get("/api/tables", (req, res) => {
  const tables = db.prepare("SELECT * FROM restaurant_tables ORDER BY number").all();
  res.json(tables.map(t => ({ ...t, booked: Boolean(t.booked) })));
});

app.patch("/api/tables/:number", (req, res) => {
  const number = Number(req.params.number);
  const { booked } = req.body;
  if (!Number.isInteger(number)) return sendError(res, 400, "Invalid table number.");
  if (typeof booked !== "boolean") return sendError(res, 400, "booked must be true or false.");

  const result = db.prepare(
    "UPDATE restaurant_tables SET booked = ? WHERE number = ?"
  ).run(booked ? 1 : 0, number);

  if (!result.changes) return sendError(res, 404, "Table not found.");
  const table = db.prepare(
    "SELECT * FROM restaurant_tables WHERE number = ?"
  ).get(number);
  res.json({ ...table, booked: Boolean(table.booked) });
});

// BILLING AND REPORTS
app.get("/api/reports", (req, res) => {
  const totals = db.prepare(`
    SELECT
      COUNT(*) AS totalOrders,
      COALESCE(SUM(CASE WHEN status = 'Paid' THEN total ELSE 0 END), 0) AS paidRevenue,
      COALESCE(SUM(CASE WHEN status != 'Paid' THEN 1 ELSE 0 END), 0) AS unpaidOrders
    FROM orders
  `).get();

  const availableTables = db.prepare(
    "SELECT COUNT(*) AS count FROM restaurant_tables WHERE booked = 0"
  ).get().count;

  const menuItems = db.prepare(
    "SELECT COUNT(*) AS count FROM foods"
  ).get().count;

  res.json({ ...totals, availableTables, menuItems });
});

// Unknown API route
app.use("/api", (req, res) => sendError(res, 404, "API endpoint not found."));

// Basic error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error." });
});

app.listen(PORT, () => {
  console.log(`ServeSmart backend running at http://localhost:${PORT}`);
  console.log("Press Ctrl+C to stop the server.");
});
