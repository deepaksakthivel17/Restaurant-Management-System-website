SERVESMART PYTHON BACKEND

Technology:
- Python
- Flask REST API
- SQLite database (built into Python)
- Flask-CORS

REQUIREMENTS
Install Python 3.10 or newer.

RUN ON WINDOWS
1. Extract the ZIP file.
2. Open the extracted folder.
3. Click the File Explorer address bar, type cmd, and press Enter.
4. Create a virtual environment (recommended):
   py -m venv venv
5. Activate it:
   venv\Scripts\activate
6. Install dependencies:
   py -m pip install -r requirements.txt
7. Start the backend:
   py app.py
8. Open this URL in Chrome:
   http://127.0.0.1:5000/api/health

The SQLite database file servesmart.db is created automatically in this
folder when the application starts. Sample food items and ten tables are
added the first time.

API ENDPOINTS
GET    /api/health
GET    /api/foods
POST   /api/foods             JSON: {"name":"Idli","price":40,"category":"Breakfast"}
DELETE /api/foods/<id>
GET    /api/orders
POST   /api/orders            JSON: {"customer":"Arun","foodId":1,"quantity":2}
PATCH  /api/orders/<id>/status JSON: {"status":"Preparing"}
GET    /api/tables
PATCH  /api/tables/<number>   JSON: {"booked":true}
GET    /api/reports

IMPORTANT
This is the Python backend API. Your existing HTML/JavaScript frontend still
uses LocalStorage and must be updated to call these API endpoints to use this
database. This demo does not include authentication or online payments.
For local development only; do not expose Flask debug mode publicly.
